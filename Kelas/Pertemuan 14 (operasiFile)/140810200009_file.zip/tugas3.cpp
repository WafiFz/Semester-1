/*
Nama     : Wafi Fahruzzaman
NPM      : 140810200009
tanggal  : 3 Desember 2020 
deskripsi: -Tugas 3- 
			Program untuk menghitung pasangan kurung kurawal yang ada pada file 
*/

#include <iostream>
#include <fstream>
using namespace std;

int periksaFile(char nFile[]);
int jumlahKarakter(char nFile[]);
void input(char nFile[]);
void output(char nFile[]);

int main(){
	char namaFile[100];
	input(namaFile);
	output(namaFile);
}

void input(char nFile[]){
	cout << "\n-PROGRAM HITUNG PASANGAN KURUNG KURAWAL-\n\n"
		 << "\nPilihan:\n- tugas1.cpp\t- tugas3.cpp\n- tugas2.cpp\t- contohFile.txt\n"
		 << "\nInput nama file yang ada di atas [tulis dengan .typeFile]: "; cin.getline(nFile, 100);
}

int periksaFile(char nFile[]){
	int periksa;
	ifstream fileText;
	fileText.open(nFile);
	if(fileText.fail()){
		periksa = 0;
	}else {
		periksa = 1;
	}
	fileText.close();
	return periksa;
}

int jumlahKarakter(char nFile[]){
	char isiFile;
	int karakter=0;
	ifstream fileTeks;
	fileTeks.open(nFile);

	while(!fileTeks.eof()){
		fileTeks.get(isiFile);
		if((isiFile == '{' || isiFile == '}') && (!fileTeks.eof())){
			karakter += 1;
		}
	}
	fileTeks.close();
	return karakter/2;
}

void output(char nFile[]){
	if (periksaFile(nFile) == 1){
		jumlahKarakter(nFile);
		cout << "\nJumlah Pasangan Kurung Kurawal : " << jumlahKarakter(nFile);
		cout << endl;
	} else {
		cout << "File '" << nFile << "' tidak ditemukan" << endl;
	}
}

void buatContohFile(){
	char contohFile[] = "contohFile.txt";
	ofstream fileteks;
	fileteks.open(contohFile);
	fileteks << "-Contoh File-\nthe quick brown fox jumps over the lazy dog"
			 << "\nTHE QUICK BROWN FOX JUMPS OVER THE LAZY DOG" << endl;
	fileteks.close();
}
