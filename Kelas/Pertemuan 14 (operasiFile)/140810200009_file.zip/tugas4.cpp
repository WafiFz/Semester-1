/*
Nama     : Wafi Fahruzzaman
NPM      : 140810200009
tanggal  : 3 Desember 2020 
deskripsi: -Tugas 4- 
			Program untuk melakukan enkripsi shift chiper suatu file teks 
*/

#include <iostream>
#include <fstream>
using namespace std;

void input(char nFile[], int& geser);
void periksaFile(char nFile[]);
void shiftChiper(char nFile[], char hasil[], int geser);
void cetakFile(char nFile[]);
void buatContohFile();

int main(){
	char namaFile[100];
	char hasil[] = "fileHasilEnkripsi.txt";
	int geser;

	buatContohFile();
	input(namaFile, geser);
	cout << endl;
	cout << "Teks sebelum dienskripsi : \n"; cetakFile(namaFile);
	shiftChiper(namaFile, hasil, geser);
	cout << "Teks setelah dienskripsi : \n"; cetakFile(hasil);
	cout << endl;
}

void input(char nFile[], int& geser){
	cout << "\n-PROGRAM ENKRIPSI SHIFT CHIPER-\n"
		 << "\nPilihan:\n- tugas1.cpp\t- tugas3.cpp\n- tugas2.cpp\t- contohFile.txt\n"
		 << "\nInput nama file yang ada di atas [tulis dengan .typeFile]: "; cin.getline(nFile, 100);
	periksaFile(nFile);
	cout << "Input besar pergeseran   : "; cin >> geser;
}	

void periksaFile(char nFile[]){
	ifstream fileteks;
	fileteks.open(nFile);
	if (fileteks.fail()){
		cout << "\nFile '" << nFile << "' tidak ditemukan" << endl;
		cout << endl;
		exit(0);
	}
	fileteks.close();
}

void shiftChiper(char nFile[], char hasil[],int geser){
	ifstream namafile;
	ofstream enkripsi;
	char karakter;
	namafile.open(nFile);
	enkripsi.open(hasil);
	
	while(!namafile.eof()){
		namafile.get(karakter);
		if (!namafile.eof() && isupper(karakter)){
			enkripsi << char(int(karakter + geser - 65) % 26 + 65);
		}else if (!namafile.eof() && islower(karakter)){
			enkripsi << char(int(karakter + geser - 97) % 26 + 97);
		}else if (!namafile.eof()){
			enkripsi << karakter;
		}
	}
	namafile.close();
	enkripsi.close();
}

void cetakFile(char nFile[]){
	ifstream namafile;
	char karakter;
	namafile.open(nFile);
	
	while(!namafile.eof()){
		namafile.get(karakter);
		if(!namafile.eof()){
			cout << karakter;
		}
	}
	cout << endl;
}

void buatContohFile(){
	char contohFile[] = "contohFile.txt";
	ofstream fileteks;
	fileteks.open(contohFile);
	fileteks << "-Contoh File-\nthe quick brown fox jumps over the lazy dog"
			 << "\nTHE QUICK BROWN FOX JUMPS OVER THE LAZY DOG" << endl;
	fileteks.close();
}
