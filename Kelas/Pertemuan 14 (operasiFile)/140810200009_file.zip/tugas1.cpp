/*
Nama     : Wafi Fahruzzaman
NPM      : 140810200009
tanggal  : 3 Desember 2020 
deskripsi: -Tugas 1- 
			Program untuk menghitung jumlah huruf vokal dan konsonan dalam suatu file
*/

#include <iostream>
#include <fstream>
using namespace std;

int periksaFile(char nFile[]);
void jumlahKarakter(char nFile[], int& vokal, int& konsonan);
void input(char nFile[]);
void output(char nFile[]);
void buatContohFile();

int main(){
	char namaFile[100];
	input(namaFile);
	output(namaFile);
}

void input(char nFile[]){
	cout << "\n-PROGRAM HITUNG KARAKTER VOKAL & KONSONAN-\n\n";
	cout << "Nama file [tulis dengan .typeFile]: "; cin.getline(nFile, 100);
}

int periksaFile(char nFile[]){
	int periksa;
	ifstream fileText;
	fileText.open(nFile);
	if(fileText.fail()){
		periksa = 0;
	}else {
		periksa = 1;
	}
	fileText.close();
	return periksa;
}

void jumlahKarakter(char nFile[], int& vokal, int& konsonan){
	char isiFile;
	ifstream fileTeks;
	fileTeks.open(nFile);

	while(!fileTeks.eof()){
		fileTeks.get(isiFile);
		if((isiFile == 'A' || isiFile == 'I' || isiFile == 'U' || isiFile == 'E' || isiFile == 'O' ||
			isiFile == 'a' || isiFile == 'i' || isiFile == 'u' || isiFile == 'e' || isiFile == 'o') 
			&& (!fileTeks.eof())){
			vokal += 1;
		}else if((isiFile >= 65 && isiFile <=90) || (isiFile >= 97 && isiFile <=122)
			&& (isiFile != 'A' || isiFile != 'I' || isiFile != 'U' || isiFile != 'E' || isiFile != 'O' ||
			isiFile != 'a' || isiFile != 'i' || isiFile != 'u' || isiFile != 'e' || isiFile != 'o') 
			&& (!fileTeks.eof())){
			konsonan += 1;
		}	 
	}
	fileTeks.close();
}

void output(char nFile[]){
	int vokal=0; 
	int konsonan=0;
	char lanjut;
	if (periksaFile(nFile) == 1){
		jumlahKarakter(nFile, vokal, konsonan);
		cout << "\nJumlah Huruf Vokal     : " << vokal
			 << "\nJumlah Huruf Konsonan  : " << konsonan;
		cout << endl;
	} else {
		cout << "File '" << nFile << "' tidak ditemukan" << endl;
		pilih:
		cout << "\nMau buat contoh file? [y/n]: "; cin >> lanjut;
		if (lanjut == 'y' || lanjut == 'Y'){
			buatContohFile();
		}else if (lanjut == 'n' || lanjut == 'N'){
			cout << "\nProgram Selesai\n";
		}else{
			cout << "\nInput dengan benar! 'y'/'n'\n";
			goto pilih;
		}
	}
}

void buatContohFile(){
	char contohFile[] = "contohFile.txt";
	ofstream fileteks;
	fileteks.open(contohFile);
	fileteks << "-Contoh File-\nthe quick brown fox jumps over the lazy dog"
			 << "\nTHE QUICK BROWN FOX JUMPS OVER THE LAZY DOG" << endl;
	fileteks.close();
	cout << "\nContoh file telah dibuat dengan nama : contohFile.txt\n"
		 << "\nPada contohFile.txt : \n";
	output(contohFile);
}